package com.restaurant.api.enums;

/**
 * UserStatus – Trạng thái tài khoản người dùng
 * ACTIVE: Đang hoạt động
 * INACTIVE: Vô hiệu hóa
 */
public enum UserStatus {
    ACTIVE,
    INACTIVE
}
