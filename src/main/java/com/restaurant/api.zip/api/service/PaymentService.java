package com.restaurant.api.service;

import com.restaurant.api.dto.notification.CreateNotificationRequest;
import com.restaurant.api.dto.payment.PaymentRequest;
import com.restaurant.api.dto.payment.PaymentResponse;
import com.restaurant.api.entity.*;
import com.restaurant.api.enums.AuditAction;
import com.restaurant.api.enums.NotificationType;
import com.restaurant.api.enums.OrderStatus;
import com.restaurant.api.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.restaurant.api.service.VoucherService;
import com.restaurant.api.dto.voucher.VoucherApplyRequest;
import com.restaurant.api.dto.voucher.VoucherApplyResponse;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.math.RoundingMode;


/**
 * PaymentService
 * ------------------------------------------------------------------------
 * Service xử lý toàn bộ nghiệp vụ THANH TOÁN:
 *
 * 1) Tạo payment cho một order:
 *    - Kiểm tra order tồn tại
 *    - Kiểm tra order đã ở trạng thái SERVING hay chưa
 *    - Kiểm tra số tiền thanh toán có khớp với totalPrice của order
 *    - Tạo record Payment
 *    - Tạo Invoice + InvoiceItem (gọi InvoiceService)
 *    - Cập nhật trạng thái order → PAID
 *
 * 2) Lấy thông tin payment theo ID
 *
 * 3) Lấy danh sách payment theo khoảng ngày
 *
 * Ghi chú quan trọng:
 * - Một order chỉ được thanh toán duy nhất một lần
 * - Khi thanh toán xong → Invoice phải được sinh tự động
 * - Mọi comment tuân theo Rule 13: viết tiếng Việt đầy đủ
 */
@Service
@RequiredArgsConstructor
public class PaymentService {

    private final PaymentRepository paymentRepository;
    private final OrderRepository orderRepository;
    private final OrderItemRepository orderItemRepository;
    private final InvoiceService invoiceService;
    private final UserRepository userRepository;
    private final NotificationService notificationService;
    private final AuditLogService auditLogService;
    private final RestaurantTableService restaurantTableService;
    private final VoucherService voucherService;
    private final SystemSettingService systemSettingService;

    // =====================================================================
    // 1. TẠO PAYMENT CHO ORDER
    // =====================================================================

    /**
     * Tạo payment cho 1 order.
     * ------------------------------------------------------------
     * Quy trình:
     *  - B1: Lấy order từ DB
     *  - B2: Kiểm tra order chưa thanh toán trước đó
     *  - B3: Kiểm tra trạng thái order = SERVING (đang phục vụ)
     *  - B4: Kiểm tra số tiền hợp lệ
     *  - B5: Tạo Payment
     *  - B6: Gọi InvoiceService để tạo hóa đơn
     *  - B7: Cập nhật trạng thái order → PAID
     */
    @Transactional
    public PaymentResponse createPayment(PaymentRequest req, String username) {

        // B1: Tìm order
        Order order = orderRepository.findById(req.getOrderId())
                .orElseThrow(() -> new RuntimeException("Không tìm thấy order"));

        // B2: Kiểm tra trạng thái
        if (order.getStatus() == OrderStatus.PAID) {
            throw new RuntimeException("Order này đã thanh toán trước đó");
        }
        if (order.getStatus() != OrderStatus.SERVING) {
            throw new RuntimeException("Chỉ order đang phục vụ mới được thanh toán");
        }

        // =====================================================================
        // B3: Tính lại số tiền cần thanh toán (có xét đến voucher nếu có)
        // =====================================================================

        // Mặc định: không dùng voucher
        BigDecimal discountAmount = BigDecimal.ZERO;
        String appliedVoucherCode = null;
        BigDecimal expectedAmount;

        String voucherCode = req.getVoucherCode();

        if (voucherCode != null && !voucherCode.trim().isEmpty()) {
            // Nếu FE gửi voucherCode → gọi lại VoucherService để tính toán chính xác
            VoucherApplyRequest applyReq = new VoucherApplyRequest();
            applyReq.setOrderId(order.getId());
            applyReq.setVoucherCode(voucherCode.trim());

            // Hàm này sẽ:
            //  - Kiểm tra hiệu lực voucher
            //  - Kiểm tra minOrderAmount, usageLimit
            //  - Tính discountAmount & finalAmount
            VoucherApplyResponse applyRes = voucherService.applyVoucher(applyReq);

            discountAmount = applyRes.getDiscountAmount();
            expectedAmount = applyRes.getFinalAmount();
            appliedVoucherCode = applyRes.getVoucherCode();
        } else {
            // Không dùng voucher → số tiền cần thanh toán = tổng tiền order
            expectedAmount = order.getTotalPrice();
        }

        // Kiểm tra số tiền FE gửi lên có khớp với số tiền cần thanh toán không
        if (req.getAmount() == null || req.getAmount().compareTo(expectedAmount) != 0) {
            throw new RuntimeException("Số tiền thanh toán không khớp với số tiền cần thanh toán");
        }

        // B4: Lấy user
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy user"));

        // B5: Lấy danh sách món order
        var orderItems = orderItemRepository.findByOrderId(order.getId());

        // =====================================================================
        // 🟢 B6: TẠO HÓA ĐƠN TRƯỚC (KHẮC PHỤC LỖI invoice_id = null)
        // =====================================================================
        Invoice invoice = invoiceService.createInvoiceFromOrder(
                order.getId(),
                req.getMethod(),
                appliedVoucherCode,   // có thể null nếu không dùng voucher
                discountAmount        // có thể 0 nếu không dùng voucher
        );

        // =====================================================================
        // 🟢 B7: TẠO PAYMENT (gắn invoice ngay lập tức)
        // =====================================================================
        Payment payment = Payment.builder()
                .order(order)
                .invoice(invoice)          // 🟢 KHÔNG ĐƯỢC ĐỂ SAU
                .amount(req.getAmount())
                .method(req.getMethod())
                .note(req.getNote())
                .paidAt(LocalDateTime.now())
                .createdBy(user.getId())
                .build();

        paymentRepository.save(payment);

        // =====================================================================
        // B8: Nếu có dùng voucher → tăng số lần sử dụng (usedCount)
        // =====================================================================
        if (appliedVoucherCode != null) {
            voucherService.increaseUsedCount(appliedVoucherCode);
        }

        // =====================================================================
        // 🟢 B8: cập nhật trạng thái Order → PAID
        // =====================================================================
        order.setStatus(OrderStatus.PAID);
        orderRepository.save(order);

        // =====================================================================
        // MODULE 16 – GIẢI PHÓNG BÀN KHI THANH TOÁN ORDER
        // =====================================================================
        if (order.getStatus() == OrderStatus.PAID) {
            if (order.getTable() != null && order.getTable().getId() != null) {
                restaurantTableService.markTableAvailable(order.getTable().getId());
            }
        }

        // =====================================================================
        // GỬI THÔNG BÁO: Tạo thanh toán
        // =====================================================================
        CreateNotificationRequest re = new CreateNotificationRequest();
        re.setTitle("Tạo thanh toán");
        re.setType(NotificationType.PAYMENT);
        re.setMessage("Tạo thanh toán");
        re.setLink("");
        notificationService.createNotification(re);

        // ✅ Audit log tạo payment
        auditLogService.log(
                AuditAction.PAYMENT_CREATE,
                "payment",
                payment.getId(),
                null,
                payment
        );

        // =====================================================================
        // Trả về kết quả
        // =====================================================================
        return toResponse(payment);
    }

    // =====================================================================
    // 2. LẤY PAYMENT THEO ID
    // =====================================================================

    @Transactional(readOnly = true)
    public PaymentResponse getPayment(Long id) {
        Payment payment = paymentRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy payment"));
        return toResponse(payment);
    }

    // =====================================================================
    // 3. FILTER PAYMENT THEO KHOẢNG NGÀY
    // =====================================================================

    @Transactional(readOnly = true)
    public List<PaymentResponse> getPayments(LocalDateTime from, LocalDateTime to) {
        List<Payment> payments;
        // Nếu FE không truyền gì → trả về toàn bộ
        if (from == null && to == null) {
            payments = paymentRepository.findAll();
        }
        // Nếu chỉ có from → lấy từ from → NOW
        else if (from != null && to == null) {
            payments = paymentRepository.findByPaidAtBetween(from, LocalDateTime.now());
        }
        // Nếu chỉ có to → lấy từ đầu → to
        else if (from == null) {
            payments = paymentRepository.findByPaidAtBetween(LocalDateTime.MIN, to);
        }
        // Nếu có đủ from và to
        else {
            payments = paymentRepository.findByPaidAtBetween(from, to);
        }

        return payments.stream()
                .map(this::toResponse)
                .toList();
    }

    // =====================================================================
    // 4. HÀM CHUYỂN ENTITY → DTO
    // =====================================================================

    private PaymentResponse toResponse(Payment p) {
        return PaymentResponse.builder()
                .id(p.getId())
                .orderId(p.getOrder().getId())
                .invoiceId(p.getInvoice() != null ? p.getInvoice().getId() : null)
                .amount(p.getAmount())
                .method(p.getMethod())
                .note(p.getNote())
                .paidAt(p.getPaidAt())
                .createdBy(p.getCreatedBy())
                .createdAt(p.getCreatedAt())
                .build();
    }
}
